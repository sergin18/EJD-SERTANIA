SITE JD SERTÂNIA

Esta versão tem:
- Fundo vinho
- Identidade "JD Sertânia"
- Apenas dois botões: Instagram e WhatsApp
- Layout adaptado para celular

ANTES DE PUBLICAR:
Abra o arquivo index.html e procure:
https://instagram.com/SEU_INSTAGRAM
https://wa.me/SEU_NUMERO

Troque pelos dados reais.

Para WhatsApp, use o número com código do Brasil, DDD e número, somente números.
Exemplo: https://wa.me/5587999999999
